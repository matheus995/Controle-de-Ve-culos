package br.unipe.excecoes;

public class DadoInvalidoException extends Exception{
	public DadoInvalidoException(){
		super("Dado inv�lido informado");
	}
}
