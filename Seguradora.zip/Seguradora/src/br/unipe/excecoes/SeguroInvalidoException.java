package br.unipe.excecoes;

public class SeguroInvalidoException extends Exception{
	public SeguroInvalidoException(){
		super("Seguro Inv�lido!");
	}
}
