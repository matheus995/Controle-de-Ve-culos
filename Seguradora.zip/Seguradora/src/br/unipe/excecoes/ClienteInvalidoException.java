package br.unipe.excecoes;

public class ClienteInvalidoException extends Exception {
	public ClienteInvalidoException(){
		super("Cliente Inv�lido");
	}
}
