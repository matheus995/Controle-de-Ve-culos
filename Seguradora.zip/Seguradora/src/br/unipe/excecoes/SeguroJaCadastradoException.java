package br.unipe.excecoes;

public class SeguroJaCadastradoException extends Exception{
	public SeguroJaCadastradoException(){
		super("Seguro Ja Cadastrado!");
	}

}
