package br.unipe.excecoes;

public class VeiculoInvalidoException extends Exception {
	public VeiculoInvalidoException(){
		super("Veiculo inv�lido!");
	}
}
