package br.unipe.view;

import java.sql.SQLException;

import javax.swing.JOptionPane;

import br.unipe.control.Fachada;
import br.unipe.excecoes.ClienteInvalidoException;
import br.unipe.excecoes.ClienteJaCadastradoException;
import br.unipe.excecoes.DadoInvalidoException;
import br.unipe.excecoes.SeguroInvalidoException;
import br.unipe.excecoes.SeguroJaCadastradoException;
import br.unipe.excecoes.VeiculoInvalidoException;
import br.unipe.excecoes.VeiculoJaCadastradoException;

public class Main {

	public static void main(String[] args) {
		JOptionPane.showMessageDialog(null,"Bem-vindo a Seguradora Exemplo");
		Fachada fachada=new Fachada();
		int opcao=0;
		while(true){
			try {
				opcao=Integer.parseInt(JOptionPane.showInputDialog("1 - Cadastrar cliente\n2 - Listar Clientes\n"
						+ "3 - Atualizar dados de Clientes\n4 - Remover Cliente\n"
						+ "5 - Cadastrar Veiculo\n6 - Listar Veiculos\n"
						+ "7 - Atualizar Veiculos\n8 - Remover Veiculos\n"
						+ "9 - Adicionar Seguro\n10 - Listar Seguros\n"
						+ "11 - Atualizar Seguro\n12 - Remover Seguro\n"
						+ "13 - Finalizar Sistema"));
				switch(opcao){
				case 1:
					
					String nome=JOptionPane.showInputDialog("Digite o nome do cliente: ");
					String profissao=JOptionPane.showInputDialog("Digite a profiss�o do cliente: ");
					String cpf=JOptionPane.showInputDialog("Digite o cpf do cliente: ");
					String email=JOptionPane.showInputDialog("Digite o email do cliente: ");
					String endereco=JOptionPane.showInputDialog("Digite o endere�o do cliente: ");
					String telefone=JOptionPane.showInputDialog("Digite o telefone do cliente: ");
					try {
						fachada.cadastrarCliente(nome,profissao, cpf, email,endereco,telefone);
						JOptionPane.showMessageDialog(null, "Cliente Cadastrado");
					} catch (ClienteJaCadastradoException e) {
						JOptionPane.showMessageDialog(null, e.getMessage());
					}catch(SQLException e){
						JOptionPane.showMessageDialog(null,e.getMessage());
					}
					
					break;
				case 2:
					try{
						fachada.listarClientes();
					}
					catch(SQLException e){
						JOptionPane.showMessageDialog(null,e.getMessage());
					}
					break;
				case 3:
					
					
					nome=JOptionPane.showInputDialog("Digite o nome do cliente: ");
					profissao=JOptionPane.showInputDialog("Digite a profiss�o do cliente: ");
					cpf=JOptionPane.showInputDialog("Digite o cpf do cliente: ");
					email=JOptionPane.showInputDialog("Digite o email do cliente: ");
					endereco=JOptionPane.showInputDialog("Digite o endere�o do cliente: ");
					telefone=JOptionPane.showInputDialog("Digite o telefone do cliente: ");
					try {
						fachada.alteraCliente(nome,profissao, cpf, email,endereco,telefone);
						JOptionPane.showMessageDialog(null, "Cliente Alterado");
					} catch (ClienteInvalidoException e) {
						JOptionPane.showMessageDialog(null,e.getMessage());
					}catch(SQLException e){
						JOptionPane.showMessageDialog(null,e.getMessage());
					}
					
					break;
				case 4:
					cpf=JOptionPane.showInputDialog("Digite o cpf do cliente: ");
					try {
						fachada.remover(cpf);
						JOptionPane.showMessageDialog(null, "Cliente Removido");
					} catch (ClienteInvalidoException e) {
						JOptionPane.showMessageDialog(null,e.getMessage());
					}catch(SQLException e){
						JOptionPane.showMessageDialog(null,e.getMessage());
					}
					break;
					
				case 5:
					
					String placa=JOptionPane.showInputDialog("Digite a placa do veiculo: ");
					String marca=JOptionPane.showInputDialog("Digite a marca do veiculo: ");
					String modelo=JOptionPane.showInputDialog("Digite o modelo do veiculo: ");
					int ano=Integer.parseInt(JOptionPane.showInputDialog("Digite o ano de fabrica��o: "));
					String cor=JOptionPane.showInputDialog("Digite a cor do veiculo: ");
					String chassi=JOptionPane.showInputDialog("Digite o chassi do veiculo: ");
					String cpfCliente=JOptionPane.showInputDialog("Digite o cpf do propriet�rio: ");
					try {
						fachada.cadastraVeiculo(placa,marca,modelo,ano,cor,chassi,cpfCliente);
						JOptionPane.showMessageDialog(null, "Veiculo Cadastrado");
					} catch (VeiculoJaCadastradoException e) {
						JOptionPane.showMessageDialog(null, e.getMessage());
					}catch(ClienteInvalidoException e){
						JOptionPane.showMessageDialog(null,e.getMessage());
					}
					catch(SQLException e){
						JOptionPane.showMessageDialog(null,e.getMessage());
					}
					
					break;
					
				
				case 6:
					try{
						fachada.listarVeiculos();
					}
					catch(SQLException e){
						JOptionPane.showMessageDialog(null,e.getMessage());
					}
					break;
					
				case 7:
					
					placa=JOptionPane.showInputDialog("Digite a placa do veiculo: ");
					marca=JOptionPane.showInputDialog("Digite a marca do veiculo: ");
					modelo=JOptionPane.showInputDialog("Digite o modelo do veiculo: ");
					ano=Integer.parseInt(JOptionPane.showInputDialog("Digite o ano de fabrica��o: "));
					cor=JOptionPane.showInputDialog("Digite a cor do veiculo: ");
					chassi=JOptionPane.showInputDialog("Digite o chassi do veiculo: ");
					cpfCliente=JOptionPane.showInputDialog("Digite o cpf do propriet�rio: ");
					try {
						fachada.alteraVeiculo(placa,marca,modelo,ano,cor,chassi,cpfCliente);
						JOptionPane.showMessageDialog(null, "Veiculo Alterado");
					} catch (VeiculoInvalidoException e) {
						JOptionPane.showMessageDialog(null, e.getMessage());
					}catch(SQLException e){
						JOptionPane.showMessageDialog(null,e.getMessage());
					}
					break;
				case 8:
					chassi=JOptionPane.showInputDialog("Digite o chassi do veiculo: ");
					try {
						fachada.removerVeiculo(chassi);
						JOptionPane.showMessageDialog(null, "Cliente Removido");
					} catch (VeiculoInvalidoException e) {
						JOptionPane.showMessageDialog(null,e.getMessage());
					}catch(SQLException e){
						JOptionPane.showMessageDialog(null,e.getMessage());
					}
					break;
					
				case 9:
					chassi=JOptionPane.showInputDialog("Digite o chassi do veiculo: ");
					String valor=JOptionPane.showInputDialog("Digite o valor do seguro: ");
					int tempo=Integer.parseInt(JOptionPane.showInputDialog("Digite o tempo de dura��o: "));
					
					try {
						fachada.adicionaSeguro(chassi,valor,tempo);
						JOptionPane.showMessageDialog(null, "Seguro Cadastrado");
					}catch (SeguroJaCadastradoException e) {
						JOptionPane.showMessageDialog(null,e.getMessage());
					} 
					catch(VeiculoInvalidoException e){
						JOptionPane.showMessageDialog(null, e.getMessage());
					}
					catch(SQLException e){
						JOptionPane.showMessageDialog(null,e.getMessage());
					}
					
					break;
				
				case 10:
					try{
						fachada.listarSeguros();
					}
					catch(SQLException e){
						JOptionPane.showMessageDialog(null,e.getMessage());
					}
					break;
				case 11:
					int id=Integer.parseInt(JOptionPane.showInputDialog("Digite o id do seguro: "));
					chassi=JOptionPane.showInputDialog("Digite o chassi do veiculo: ");
					valor=JOptionPane.showInputDialog("Digite o valor do seguro: ");
					tempo=Integer.parseInt(JOptionPane.showInputDialog("Digite o tempo de dura��o: "));
					
					try {
						fachada.alteraSeguro(id,chassi,valor,tempo);
						JOptionPane.showMessageDialog(null, "Seguro alterado");
					}catch (SeguroInvalidoException e) {
						JOptionPane.showMessageDialog(null,e.getMessage());
					}
					catch(SQLException e){
						JOptionPane.showMessageDialog(null,e.getMessage());
					}
					
					break;
				case 12:
					id=Integer.parseInt(JOptionPane.showInputDialog("Digite o id do seguro: "));
					try {
						fachada.removerSeguro(id);
						JOptionPane.showMessageDialog(null, "Seguro Removido");
					} catch (VeiculoInvalidoException e) {
						JOptionPane.showMessageDialog(null,e.getMessage());
					}catch(SQLException e){
						JOptionPane.showMessageDialog(null,e.getMessage());
					}
					break;
				case 13:
					System.exit(0);
					break;
				default:
					JOptionPane.showMessageDialog(null,"Informe uma op��o v�lida");
				
				}
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null,new DadoInvalidoException().getMessage());
			}
		}
	}
	
	
}
